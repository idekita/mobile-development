package com.capstone.idekita.ui.tes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.capstone.idekita.R

class testes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_testes)
    }
}