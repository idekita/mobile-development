package com.capstone.idekita.ui.addProject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.capstone.idekita.R

class AddProjectActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_project)
    }
}